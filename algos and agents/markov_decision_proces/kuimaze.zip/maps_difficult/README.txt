maze creator from:
http://hereandabove.com/maze/mazeorig.form.html